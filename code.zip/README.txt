Python 3 requirements:
numpy
matplotlib
jupyter-lab
pandas
seaborn

How to execute:
Run Milestone_1.pynb in jupyter notebook.
Make sure graphs\ and data\ are in the current directory.
Generated graphs will be in graphs\ and csv files will be in data\
NOTE: May take a couple minutes to run.

Filestructure:
code\
  |
  ---->graphs\
  |
  ---->data\